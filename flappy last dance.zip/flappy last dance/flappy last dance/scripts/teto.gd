extends CollisionShape2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"


# Called when the node enters the scene tree for the first time.
func _ready():
	var colisao = move_and_collide(Vector2(-Global.velocidade , 0) * delta )
func _on_passsaro_body_entered(body):

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass
