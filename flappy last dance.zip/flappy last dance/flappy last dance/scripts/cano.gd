extends KinematicBody2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"


# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	var colisao = move_and_collide(Vector2(-Global.velocidade , 0) * delta ) 
	
	
	if colisao != null:
		if colisao.collider.name == "passsaro":
			Global.velocidade = 0
			Global.velocidadenuvem = 0
			Global.velocidadearvore = 0
			
