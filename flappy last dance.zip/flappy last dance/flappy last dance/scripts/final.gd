extends Node2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"


# Called when the node enters the scene tree for the first time.
func _ready():
	get_tree().call_group("canos", "queue_free")
	get_tree().call_group("moedas", "queue_free")
	get_node("pontuação").text= "Pontuação: " + str(Global.pontos)

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass
