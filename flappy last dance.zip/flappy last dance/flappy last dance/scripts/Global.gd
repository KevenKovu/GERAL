extends Node


# Declare member variables here. Examples:
var velocidade = 150
var velocidadenuvem = 150
var velocidadearvore = 200
var pontos = 0

# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass
