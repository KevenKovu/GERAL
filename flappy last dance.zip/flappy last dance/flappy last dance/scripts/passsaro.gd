extends RigidBody2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"

var lock_rot
var lock_x

# Called when the node enters the scene tree for the first time.
func _ready():
	lock_rot = self.rotation
	lock_x = self.position.x


func _physics_process(delta):
	pass

func _process(delta):
	if Input.is_action_just_pressed("salto"):
		apply_central_impulse(Vector2(0,-400))
	
	self.rotation = lock_rot
	self.position.x = lock_x
	
	
	

func _on_passsaro_body_entered(body):
	if body.name.find("Cano") >-1:
		Global.velocidade = 0
		get_tree().change_scene("res://scenes/final.tscn")
	if body.name.find("teto") > - 1:
		transform.rotated(0)
	if body.name.find("chao") > - 1:
		get_tree().change_scene("res://scenes/final.tscn")
	if body.name.find("moeda") >-1:
		body.queue_free()
		Global.pontos += 5
	
	
	
	
	
	
	
	
