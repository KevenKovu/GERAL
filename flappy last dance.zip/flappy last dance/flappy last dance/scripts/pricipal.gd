extends Node2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"
var dalay_moeda = 5
var dalay_canos = 6
var CANO
var rng
var MOEDA
# Called when the node enters the scene tree for the first time.
func _ready():
	CANO = preload("res://comp/cano.tscn")
	rng = RandomNumberGenerator.new()
	MOEDA =  preload("res://comp/moeda.tscn")
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process (delta):
	if dalay_canos > 2:
		var cano_cima = CANO.instance()
		get_tree().get_root().add_child(cano_cima)
		cano_cima.position = get_node("posiçao cano cima").position 
		cano_cima.scale.y = -1
		cano_cima.position += Vector2(0,rng.randi_range(-150,0))
		
		rng.randomize()
		
		#algoritimo do cano de baixo	
		var cano_baixo = CANO.instance()
		get_tree().get_root().add_child(cano_baixo)
		cano_baixo.position = get_node("posiçao cano baixo").position 
		cano_baixo.position += Vector2(0,rng.randi_range(0,150))
		dalay_canos = 0
	else:
		dalay_canos += delta
	
	
	if dalay_moeda >=5 :
		var criarmoeda =  MOEDA.instance()
		get_tree().get_root().add_child(criarmoeda)
		criarmoeda.position = get_node("posiçao moeda").position
		dalay_moeda = 0 
		
	else:
		dalay_moeda += delta
	
	
	
	
	
func _on_fim_cano_body_entered(body):
	body.queue_free()
	
	
	
	


func _on_pontos_cano_body_entered(body):
	Global.pontos = Global.pontos + 0.5
	get_node("pontuação").text= "Pontuação: " + str(Global.pontos)
