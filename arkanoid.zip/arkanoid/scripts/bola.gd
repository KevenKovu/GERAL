extends KinematicBody2D


# Declare member variables here. Examples:
var vx = 350
var vy = -350

var iniciox
var inicioy
# Called when the node enters the scene tree for the first time.

func _ready():
	iniciox = position.x
	inicioy = position.y


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	var colisao = move_and_collide(Vector2(vx,vy) * delta)
	
	if colisao != null:
		if colisao.collider.name == "parede":
			vx = -vx
		
		
		if colisao.collider.name == "teto":
			vy = -vy
			
		
		if colisao.collider.name == "jogador":
			vy = -vy
			
		if colisao.collider.name == "base":
			position.x = iniciox
			position.y = inicioy
			vx = 350 + (0.03*350)
			vy = -350 + (0.03*-350)
		
		
		if colisao.collider.is_in_group("bloco"):
			colisao.collider.reduzir_hp()
			vy = -vy
			Global.pontos = Global.pontos + 1
			get_node("../rotulo pontuação").text = "Pontuação: " +str(Global.pontos)
