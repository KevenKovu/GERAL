extends KinematicBody2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"


# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):

	if Input.is_action_pressed("jogador_esquerda"):
		move_and_collide(Vector2(-330,0)* delta)
	
	if Input.is_action_pressed("jogador_direita"):
		move_and_collide(Vector2(330,0)* delta)
