extends Node


# Declare member variables here. Examples:
var pontos = 0 

