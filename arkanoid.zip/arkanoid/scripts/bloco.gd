extends StaticBody2D
#pontos de vida
var hp = 8
#rotina pra trocar de cor o bloco
func reduzir_hp():
	if hp == 8 :
		get_node("Bloco8").visible = false
		get_node("Bloco7").visible = true
		
	if hp == 7:
		get_node("Bloco7").visible = false
		get_node("Bloco6").visible = true
	
	if hp == 6:
		get_node("Bloco6").visible = false
		get_node("Bloco5").visible =true
	
	if hp == 5 :
		get_node("Bloco5").visible = false
		get_node("Bloco4").visible = true
	
	if hp == 4:
		get_node("Bloco4").visible = false
		get_node("Bloco3").visible = true
	
	if hp == 3 :
		get_node("Bloco3").visible = false
		get_node("Bloco2").visible = true
		
	if hp == 2:
		get_node("Bloco2").visible = false
		get_node("Bloco1").visible = true
	
	if hp == 1 :
		queue_free()# destruir bloco
	
	hp = hp - 1
