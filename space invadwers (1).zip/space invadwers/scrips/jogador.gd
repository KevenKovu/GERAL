extends KinematicBody2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"

var TIRO
# Called when the node enters the scene tree for the first time.
func _ready():
	TIRO = preload("res://comp/BALET.tscn")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	if Input.is_action_pressed("mover_direita"):
		move_and_collide(Vector2(200,0)*delta)
			
	if Input.is_action_pressed("mover_esquerda"):
		move_and_collide(Vector2(-200,0)*delta)
		
	if Input.is_action_pressed("tiro"):
		var tiro = TIRO.instance()
		get_tree().get_root().add_child(tiro)
		tiro.position = self.position
